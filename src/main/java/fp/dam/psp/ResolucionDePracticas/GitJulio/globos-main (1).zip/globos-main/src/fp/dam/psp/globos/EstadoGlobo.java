package fp.dam.psp.globos;

public enum EstadoGlobo {
    DESHINCHADO, HINCHANDO, EXPLOTADO, PINCHADO
}
