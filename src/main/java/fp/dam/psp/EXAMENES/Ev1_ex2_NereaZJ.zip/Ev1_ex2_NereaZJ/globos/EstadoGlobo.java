package fp.dam.psp.EXAMENES.Ev1_ex2_NereaZJ.globos;

public enum EstadoGlobo {
    DESHINCHADO, HINCHANDO, EXPLOTADO, PINCHADO
}
